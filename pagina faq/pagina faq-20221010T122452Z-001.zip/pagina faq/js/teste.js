$(".drop")
.mouseover(function() {
$(".dropdown").show(300);
});
$(".drop")
.mouseleave(function() {
$(".dropdown").hide(300);     
});